---
name: Executive Analytics Portfolio
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#44474d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#75777e'
  outline-variant: '#c5c6ce'
  surface-tint: '#4f5f7a'
  primary: '#000818'
  on-primary: '#ffffff'
  primary-container: '#0f2038'
  on-primary-container: '#7888a5'
  inverse-primary: '#b7c7e7'
  secondary: '#4d6076'
  on-secondary: '#ffffff'
  secondary-container: '#d0e4ff'
  on-secondary-container: '#53667c'
  tertiary: '#000913'
  on-tertiary: '#ffffff'
  tertiary-container: '#002238'
  on-tertiary-container: '#218ed2'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#b7c7e7'
  on-primary-fixed: '#0a1c34'
  on-primary-fixed-variant: '#384761'
  secondary-fixed: '#d0e4ff'
  secondary-fixed-dim: '#b4c8e2'
  on-secondary-fixed: '#071d30'
  on-secondary-fixed-variant: '#35485d'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-hero:
    fontFamily: Hanken Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Hanken Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.015em
  headline-lg:
    fontFamily: Hanken Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Hanken Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
  metric-display:
    fontFamily: Hanken Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes a high-caliber digital identity for an emerging professional in Information Systems and Business Analytics from the Sam M. Walton College of Business. The visual language blends elite corporate credibility with technical, analytical precision. 

The aesthetic sits at the intersection of modern corporate governance and crisp enterprise data platforms. The interface conveys disciplined execution, analytical rigor, academic excellence, and business acumen. The experience avoids flashy animations or distracting novelties, prioritizing clarity, hierarchy, scannability, and institutional trust for prospective employers, corporate recruiters, and academic peers.

## Colors

The palette is anchored in an authoritative Deep Navy (`#0F2038`), reflecting collegiate distinction and enterprise stability. Supporting tones include:
- **Primary (`#0F2038`):** Dominates primary typographic headings, key structural boundaries, and high-emphasis focal elements.
- **Secondary (`#4A5D73`):** Slate Gray for sub-headers, timelines, company metadata, and neutral UI indicators.
- **Tertiary / Accent (`#0284C7`):** Ice / Cerulean Blue providing controlled focal highlights for active project links, high-value metrics, credentials, and interactive states.
- **Neutral Surface (`#F8FAFC`):** Crisp, untinted cool white canvas that enhances readability and typographic sharpness, accented by subtle slate border dividers (`#E2E8F0`).

## Typography

The type scale combines **Hanken Grotesk** for structured, architectural headlines with **Inter** for exceptional body legibility and technical clarity. 

- Numeric values such as GPAs, academic honors, dates, and quantitative project outputs must activate tabular figures (`font-variant-numeric: tabular-nums`) to ensure vertical alignment across data cards and multi-column timeline entries.
- Section tags, category labels, and status badges use `label-caps` styled with `text-transform: uppercase` to introduce structural definition without requiring intrusive graphical dividers.

## Layout & Spacing

The portfolio is architected on a centered, responsive 12-column grid container capped at a maximum width of 1200px:
- **Desktop (1024px+):** 12 columns, 24px (`1.5rem`) gutters, 48px (`3rem`) outer margins. Experience and education entries leverage an asymmetrical 4:8 split (meta/timeline to detailed responsibilities).
- **Tablet (768px - 1023px):** 8 columns, 20px gutters, 32px outer margins. Two-column cards collapse gracefully.
- **Mobile (< 768px):** 4 columns, 16px (`1rem`) gutters, 20px (`1.25rem`) outer margins. Layout stacks vertically in strict single-column order with high-contrast milestone badges.

## Elevation & Depth

This system relies primarily on razor-sharp, low-contrast structural outlines and subtle tonal differentiation rather than heavy drop shadows:
- **Base Surfaces:** Pure `#FFFFFF` card elements seated above an ultra-light cool canvas `#F8FAFC`.
- **Card Framing:** 1px borders using `#E2E8F0` provide clear, dignified delineation for analytical cards, honor entries, and project highlights.
- **Interactive Focus & Hover:** On hover, surfaces raise with a microscopic shift using an ultra-fine shadow: `0 4px 12px -2px rgba(15, 32, 56, 0.06), 0 2px 6px -1px rgba(15, 32, 56, 0.04)` combined with a subtle border transition to `#CBD5E1`.

## Shapes

The design uses a clean, disciplined corner profile (`roundedness: 1`):
- Standard content containers, credential cards, and input fields utilize `rounded` (0.25rem / 4px) to retain an executive, corporate stationery structure.
- Badges and skill tags utilize `rounded-md` (0.375rem / 6px) to slightly soften analytical chips without appearing playful.
- Circular icons and status pips use full circular masks (`rounded-full`).

## Components

### Buttons
- **Primary:** Solid `#0F2038` background, `#FFFFFF` text, `rounded` (4px), 12px vertical by 24px horizontal padding. Hover shifts smoothly to `#1E3A5F`.
- **Secondary / Outline:** Transparent fill, 1px solid `#CBD5E1`, `#0F2038` text. Hover transitions to `#F1F5F9` background and `#0F2038` border.
- **Link Action:** Ice Blue `#0284C7` text with a forward caret or arrow indicator, featuring a subtle bottom border accent.

### Badges & Analytical Chips
- **Tool Badges (SAS Viya, Tableau, QuickBooks, etc.):** Rendered with a `#F1F5F9` background, `#0F2038` text, and a crisp 1px `#E2E8F0` border. Paired with small monochrome tool icons or category pips.
- **Honor & Status Badges:** Soft ice-blue tinted background (`#E0F2FE`), `#0369A1` text, 4px border-radius, `label-caps` typography.

### Metric Callout Cards (GPA, Awards, Credentials)
- Compact white surface featuring an oversized tabular metric (`metric-display`) positioned above a slate description label (`label-caps`). Left-bordered with a 3px vertical accent bar in `#0284C7`.

### Timeline & Experience Units
- Linear chronological stem in `#E2E8F0` with a 10px `#0F2038` node pip. 
- Date range displayed in tabular font in the left column; role title, company name, location, and bulleted achievements in the right content column.

### Contact & Portfolio Action Bar
- Clean horizontal utility bar housing direct contact methods (email, phone, LinkedIn) with muted monochrome iconography and clear click-to-copy or external link indicators.